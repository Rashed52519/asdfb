Place service folders here:
- codex: Shopify eligibility + sync + webhooks.
- dispatch: assignment logic.
- courier: driver APIs.
Start by creating `codex/` for T1–T3.
