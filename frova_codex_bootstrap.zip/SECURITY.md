# Security
- No PII in logs. Mask tokens and phone numbers.
- HTTPS only. Timeouts and retries with backoff.
- Secrets from env only. JWT short-lived.
