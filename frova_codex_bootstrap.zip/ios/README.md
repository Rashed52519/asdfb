# Frova Driver — iOS
- iOS 17, SwiftUI. Arabic/RTL. No external packages.
- Create Xcode project at `ios/FrovaDriver` with targets: app + tests.
- Networking endpoints to call later:
  - /driver/auth/issue
  - /driver/jobs
  - /driver/jobs/{id}/accept
  - /driver/jobs/{id}/pod
